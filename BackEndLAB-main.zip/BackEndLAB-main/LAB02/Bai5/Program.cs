﻿//Bài 5: Viết hàm hoán vị 2 số nguyên a và b nhập từ bàn phím.

static void Swap(ref int a, ref int b)
{
    int temp = a;
    a = b;
    b = temp;
}
